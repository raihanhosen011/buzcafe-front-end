import React from 'react'

function index() {
    return (
        <div>
           <a href='https://kycdapp.com/' target='_blank' className='button button--white text-center my-4' > Redirect to KYC </a> 
        </div>
    )
}

export default index
