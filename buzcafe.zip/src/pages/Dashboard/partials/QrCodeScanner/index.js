import React from 'react'

function index() {
    return (
        <>
          <div className='qr-scanner' >
            <h4 className='dashboard__title text-center' > Your QR code </h4>

            <h4 className='dashboard__title text-center' > Download QR </h4>
          </div>   
        </>
    )
}

export default index
