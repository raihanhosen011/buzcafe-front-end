import React from 'react'
import './hero.css'

function index() {
    return (
        <>
           <section className='hero' > </section>
        </>
    )
}

export default index
